@echo off
start "" "%~dp0NeuroRing.exe" --stop
